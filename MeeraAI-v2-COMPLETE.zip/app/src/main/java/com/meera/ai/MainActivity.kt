package com.meera.ai

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.meera.ai.automation.QuickAccess
import com.meera.ai.ui.AboutScreen
import com.meera.ai.ui.AutomationScreen
import com.meera.ai.ui.CallScreen
import com.meera.ai.ui.ChatScreen
import com.meera.ai.ui.HomeScreen
import com.meera.ai.ui.MemoryScreen
import com.meera.ai.ui.PermissionsScreen
import com.meera.ai.ui.SettingsScreen
import com.meera.ai.ui.ToolsScreen
import com.meera.ai.ui.MeeraTheme

class MainActivity : ComponentActivity() {
    private val routeRequest = mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        routeRequest.value = intent?.getStringExtra("route")
        if (Meera.settings.quickAccess) QuickAccess.show(this)
        setContent {
            val theme by Meera.settings.themeFlow.collectAsState()
            MeeraTheme(theme) {
                MeeraRoot(routeRequest.value) { routeRequest.value = null }
                ConfirmDialog()
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        routeRequest.value = intent.getStringExtra("route")
    }
}

private val mainRoutes = listOf("home", "chat", "call", "coding", "settings")

fun NavHostController.go(route: String) {
    navigate(route) {
        popUpTo(graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

@Composable
fun MeeraRoot(requested: String?, consumed: () -> Unit) {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    LaunchedEffect(requested) {
        if (requested != null) { nav.go(requested); consumed() }
    }
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            if (route in mainRoutes) {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                    val items = listOf(
                        Triple("chat", "💬", Icons.Filled.Send),
                        Triple("call", "📞", Icons.Filled.Call),
                        Triple("coding", "</>", Icons.Filled.Build)
                    )
                    items.forEach { (r, label, icon) ->
                        NavigationBarItem(
                            selected = route == r,
                            onClick = { nav.go(r) },
                            icon = {
                                if (r == "coding") Text("</>", color = MaterialTheme.colorScheme.onSurface, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                                else Icon(icon, contentDescription = null)
                            },
                            label = {},
                            alwaysShowLabel = false
                        )
                    }
                }
            }
        }
    ) { pad ->
        NavHost(nav, startDestination = "home", modifier = Modifier.padding(pad)) {
            composable("home") { HomeScreen(nav) }
            composable("chat") { ChatScreen(Meera.chat, "Meera Chat", coding = false) }
            composable("call") { CallScreen() }
            composable("coding") { ChatScreen(Meera.coding, "Coding Assistant", coding = true) }
            composable("settings") { SettingsScreen() }
            composable("automation") { AutomationScreen { nav.popBackStack() } }
            composable("memory") { MemoryScreen { nav.popBackStack() } }
            composable("tools") { ToolsScreen { nav.popBackStack() } }
            composable("permissions") { PermissionsScreen { nav.popBackStack() } }
            composable("about") { AboutScreen { nav.popBackStack() } }
        }
    }
}

@Composable
fun ConfirmDialog() {
    val list by Meera.pending.collectAsState()
    val p = list.firstOrNull() ?: return
    AlertDialog(
        onDismissRequest = { Meera.resolve(p, false) },
        title = { Text(p.title) },
        text = { Text(p.detail) },
        confirmButton = { TextButton(onClick = { Meera.resolve(p, true) }) { Text("Yes") } },
        dismissButton = { TextButton(onClick = { Meera.resolve(p, false) }) { Text("No") } }
    )
}
