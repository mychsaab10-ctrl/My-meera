package com.meera.ai.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.meera.ai.R
import com.meera.ai.Meera
import androidx.compose.runtime.getValue
import com.meera.ai.go
import java.time.LocalTime

@Composable
fun HomeScreen(nav: NavHostController) {
    val hour = LocalTime.now().hour
    val hi = when {
        hour < 5 -> "Itni raat ko jaag rahe ho? 🌙"
        hour < 12 -> "Good morning ☀️"
        hour < 17 -> "Assalam-o-alaikum ✨"
        hour < 21 -> "Good evening 🌆"
        else -> "Shab bakhair 🌙"
    }
    val hasKey = Meera.keys.has()
    val avatarEmotion by Meera.avatarEmotion.collectAsState()
    val avatarRes = when (avatarEmotion) {
        "thinking" -> R.drawable.meera_thinking
        "speaking" -> R.drawable.meera_speaking
        "sad" -> R.drawable.meera_sad
        "love" -> R.drawable.meera_love
        "excited" -> R.drawable.meera_excited
        else -> R.drawable.meera_happy
    }
    var menuExpanded by remember { mutableStateOf(false) }
    var ownerDialog by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(androidx.compose.ui.graphics.Color(0xFF090D1C), androidx.compose.ui.graphics.Color(0xFF15132D))))
            .verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box {
                Surface(color = androidx.compose.ui.graphics.Color(0xFF20243A), shape = RoundedCornerShape(14.dp)) {
                    Text("☰", Modifier.clickable { menuExpanded = true }.padding(horizontal = 16.dp, vertical = 10.dp),
                        color = androidx.compose.ui.graphics.Color.White, fontSize = 23.sp)
                }
                DropdownMenu(expanded = menuExpanded, onDismissRequest = { menuExpanded = false }) {
                    listOf(
                        "Memory" to "memory", "Phone automations" to "automation",
                        "Tools & docs" to "tools", "Permissions" to "permissions",
                        "Settings" to "settings", "About" to "about"
                    ).forEach { (label, route) ->
                        DropdownMenuItem(text = { Text(label) }, onClick = { menuExpanded = false; nav.go(route) })
                    }
                    DropdownMenuItem(text = { Text("Owner details") }, onClick = { menuExpanded = false; ownerDialog = true })
                }
            }
            Spacer(Modifier.width(14.dp))
            Column {
                Text("MEERA AI", color = androidx.compose.ui.graphics.Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                Text("PERSONAL AI LAB  •  ONLINE", color = androidx.compose.ui.graphics.Color(0xFF63E8FF), fontSize = 10.sp, letterSpacing = 1.2.sp)
            }
            Spacer(Modifier.weight(1f))
            Text(if (hasKey) "●" else "○", color = if (hasKey) androidx.compose.ui.graphics.Color(0xFF63E8FF) else androidx.compose.ui.graphics.Color(0xFFFF8AA8), fontSize = 22.sp)
        }
        Spacer(Modifier.height(4.dp))
        Text("$hi", color = androidx.compose.ui.graphics.Color(0xFFB8C6E8), fontSize = 15.sp)
        Image(
            painter = painterResource(id = avatarRes),
            contentDescription = "Meera AI avatar",
            modifier = Modifier.fillMaxWidth().heightIn(min = 280.dp, max = 390.dp)
                .clip(RoundedCornerShape(26.dp))
        )
        Text("Main yahan hoon, Adil! 💙", color = androidx.compose.ui.graphics.Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Baat karni ho, coding karni ho ya phone par koi kaam — bas batao.",
            color = androidx.compose.ui.graphics.Color(0xFFB8C6E8), fontSize = 13.sp)
        if (!hasKey) {
            GlowCard(Modifier.fillMaxWidth(), onClick = { nav.go("settings") }) {
                Text("Settings mein apni Gemini API key add karein.", color = MaterialTheme.colorScheme.onSurface)
            }
        }
        Spacer(Modifier.height(12.dp))
    }
    if (ownerDialog) {
        AlertDialog(
            onDismissRequest = { ownerDialog = false },
            title = { Text("Owner details") },
            text = { Text("App Name: MEERA AI\\n\\nDeveloped By: CH ADiL\\n\\n© 2026 CH ADiL - All Rights Reserved.") },
            confirmButton = { TextButton(onClick = { ownerDialog = false }) { Text("Close") } }
        )
    }
}
